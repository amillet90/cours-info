ATTENTION : 
Afin d'éviter les "Rechercher"/"Remplacer" sans ne rien comprendre au principe de routage, ce code source a été modifié par rapport au TP :
* la convention du nom des routes a été modifiée, le verbe (l'action) est placé avant le nom de l'objet (table, entité) 
* la convention du nom des fonctions dans app.py a été modifiée, le nom de l'objet (table, entité)  est placé avant  le verbe (l'action)
* la convention du nom des fichiers templates a été modifiée, le verbe (l'action) est placé après le nom de l'objet (table, entité)