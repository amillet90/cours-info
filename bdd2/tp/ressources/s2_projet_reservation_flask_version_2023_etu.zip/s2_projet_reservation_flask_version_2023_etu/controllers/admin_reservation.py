#! /usr/bin/python
# -*- coding:utf-8 -*-
from flask import Blueprint
from flask import Flask, request, render_template, redirect, url_for, abort, flash, session, g

from connexion_db import get_db

from datetime import date

admin_reservation = Blueprint('admin_reservation', __name__,
                        template_folder='templates')

@admin_reservation.route('/admin/reservation/adherent-select')
def reservation_select_adherent():
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete5_1' FROM DUAL '''
    mycursor.execute(sql)
    donneesClients = mycursor.fetchall()
    return render_template('admin/reservation/select_client_reservations.html', donneesClients=donneesClients, erreurs=[])





@admin_reservation.route('/admin/reservation/reserver', methods=['POST'])
def reservation_reserver():
    mycursor = get_db().cursor()
    donnees={}
    idClient = request.form.get('idClient', '')
    print(idClient)
    if idClient == '':
        sql = ''' SELECT 'requete5_???' FROM DUAL '''
        mycursor.execute(sql,(idClient))
        donneesClient = mycursor.fetchall()
        #donneesClient = mReservation.find_clients_reservations()
        erreurs={'idClient': u'Selectionner un client'}
        return render_template('admin/reservation/select_client_reservations.html', donneesClients=donneesClient, erreurs=erreurs)


    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql,(idClient))
    nbReservations = mycursor.fetchone()
    #nbReservations = mClient.getNbReservationClient(idClient)




    dateDebut = request.form.get('dateDebut', None)
    dateFin = request.form.get('dateFin', None)
    nbLits = request.form.get('nbLits',None)
    idStation = request.form.get('idStation',None)


    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql,(idClient))
    donneesClient = mycursor.fetchone()

    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql)
    donneesStations = mycursor.fetchall()

    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql, (idClient))
    donneesReservation = mycursor.fetchall()

    #donneesClient = mClient.getClient(idClient)
    #donneesReservation = mReservation.getInfoReservation(idClient)
    #donneesStations = mStation.getAllStations()

    listeChambres = []

    if dateFin != None:
        donnees["dateFin"] = dateFin
    if dateDebut != None:
        donnees["dateDebut"] = dateDebut
    if nbLits != None:
        donnees["nbLits"] = nbLits
    if idStation != None:
        donnees["idStation"] = idStation

    valid, erreurs, donnees = validator_reservation(donnees)

    if idStation != None and dateFin != None and dateDebut != None and nbLits != None:
        listeChambres = mReservation.find_chambres(donnees["idStation"],donnees["nbLits"],donnees["dateDebut"],donnees["dateFin"])

    print(listeChambres)

    return render_template('admin/reservation/add_reservations.html',
            donneesClient = donneesClient,
            listeChambresDispo = listeChambres,
            donneesStations = donneesStations,
            donneesReservations = donneesReservation,
            nbReservations = nbReservations,
            donnees = donnees,
            erreurs = erreurs)


@admin_reservation.route('/admin/reservation/show', methods=["GET"])
def reservation_show():
    annee= str(request.args.get("annee"))
    mois = str(request.args.get("mois"))
    dateDebut= annee+"-"+mois+"-01"
    nbJourDansMois = [31,28,31,30,31,30,31,31,30,31,30,31][int(mois)-1]
    dateFin= annee+"-"+mois+"-"+str(nbJourDansMois)
    idStation = request.args.get("idStation",None)


    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql)
    allStations = mycursor.fetchall()

    #allStations = mStation.getAllStations()


    if idStation == "noid":
        listeStation = mStation.getAllStations()
    else:
        idStation = int(idStation)
        sql = ''' SELECT 'requete5_??' FROM DUAL '''
        mycursor.execute(sql)
        listeStation = mycursor.fetchall()
        #listeStation = [mStation.getStation(idStation)]

    restot=[]
    for station in listeStation:
        ##
        sql = ''' SELECT 'requete5_??' FROM DUAL '''
        mycursor.execute(sql, (idClient))
        listeHotels = mycursor.fetchall()
        #listeHotels = mHotel.getHotelInStation(station["idStation"])

        restot.append({"nomStation":station["nomStation"],"listeHotels":[]})

        for hotel in listeHotels:
            restot[-1]["listeHotels"].append({"nomHotel":hotel["nomHotel"],"chambres":{}})
            listeChambre = mChambre.getAllChambresInHotel(hotel["idHotel"])
            for chambre in listeChambre:
                numero=chambre['numChambre']
                res=[]
                temp=mReservation.getInfoOnChambre(hotel["idHotel"],numero,dateFin,dateDebut)
                valtemp=0
                for i in range(nbJourDansMois):
                    for reservation in temp:
                        if (reservation['moisdebut']<int(mois) or reservation['jourdebut']<=i+1) and (reservation['jourfin']>i or reservation['moisfin']>int(mois)):
                            valtemp=1
                        else:
                            valtemp=0
                    res.append(valtemp)
                restot[-1]["listeHotels"][-1]["chambres"][numero]=(numero,chambre['nbLits'],chambre['prixLocation'],res)
    return render_template('admin/reservation/show_reservation.html',result=restot,donnees={"annee":annee,"mois":mois},erreurs={},
                           stations=allStations,idStation=idStation,nbJoursMois=nbJourDansMois)


###################### À MODIFIER
@admin_reservation.route('/admin/reservation/rendre', methods=['POST'])
def reservation_rendre():
    mycursor = get_db().cursor()
    idAdherent = request.form.get('idAdherent', '')
    if idAdherent == '':
        sql = ''' SELECT 'requete5_??' FROM DUAL '''
        mycursor.execute(sql)
        donneesAdherents = mycursor.fetchall()
        erreurs={'idAdherent': u'Selectionner un adhérent'}
        return render_template('admin/reservation/select_client_reservations.html', donneesAdherents=donneesAdherents,
                                   action='rendre', erreurs=erreurs)


    dateEmprunt = request.form.get('dateEmprunt', '')
    noExemplaire = request.form.get('noExemplaire', '')
    dateRetour = request.form.get('dateRetour', '')

    if idAdherent != '' and dateEmprunt != '' and noExemplaire !='' and dateRetour != '' :
        # traitement des erreurs
        tuple_update = (dateRetour, idAdherent,dateEmprunt,noExemplaire)
        print(tuple_update)
        sql = ''' SELECT 'requete5_??' FROM DUAL '''
        mycursor.execute(sql, tuple_update)
        get_db().commit()

    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql,(idAdherent))
    donneesAdherent = mycursor.fetchone()
    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql,(idAdherent))
    nbrEmprunts = mycursor.fetchone()
    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    mycursor.execute(sql,(idAdherent))
    donneesEmprunts = mycursor.fetchall()

    donnees={}
    if 'dateRetour' not in donnees.keys() or donnees['dateRetour'] == '':
        donnees['dateRetour'] = date.today().strftime("%Y-%m-%d")


    return render_template('admin/reservation/return_reservations.html' , donneesAdherents=donneesAdherent,
            donneesEmprunt = donneesEmprunts,
            nbrEmprunts = nbrEmprunts,
            donnees = donnees,
            erreurs = {})



@admin_reservation.route('/admin/reservation/delete', methods=['GET','POST'])
def delete_reservation_valid():
    mycursor = get_db().cursor()
    idClient = request.args.get('idClient', 'pasid')
    if request.method == 'POST':
        list_reservations=request.form.getlist('select_reservation')
        if(len(list_reservations)>=1):
            print(list_reservations)
            for elt in list_reservations:
                list_reservations_split=elt.split('_')
                print(list_reservations_split)
                print()
                if len(mHotel.getHotel(int(list_reservations_split[1]))) == None:
                    message = u'reservation à supprimé, PB , Hotel inexistant :' + str(elt)
                    flash(message)
                    return redirect('/admin/reservation/delete')
                mReservation.reservation_delete(list_reservations_split)
            message = u'reservation(s) supprimé(s)'
            flash(message)
        return redirect('/admin/reservation/delete')

    sql = ''' SELECT 'requete5_??' FROM DUAL '''
    if idClient.isnumeric():
        sql = sql + " WHERE C.idClient ="+str(idClient)
        idClient = int(idClient)
    sql=sql + " ORDER BY C.nomClient, R.dateDebut"

    mycursor.execute(sql)
    donnees = mycursor.fetchall()

    for i in range(len(donnees)):
        donnees[i]["dateDebut"] = str(donnees[i]["dateDebut"])
    donneesAdherents = mClient.getAllClients()
    return render_template('admin/reservation/delete_all_reservations.html', donnees=donnees, donneesAdherents=donneesAdherents,idClient=idClient)


@admin_reservation.route('/admin/reservation/bilan-retard', methods=['GET'])
def bilan_reservation():
    donneesBilan = mReservation.getCAHotels()
    return render_template('admin/reservation/bilan_reservation.html', donnees=donneesBilan)






def validator_reservation(data):
    valid = True
    errors = dict()
    if 'nbLits' in data.keys():
        if not data['nbLits'].isdecimal():
           errors['nbLits'] = 'type nbLits incorrect'
           valid= False
        else:
            data["nbLits"] = int(data["nbLits"])

    if 'idStation' in data.keys():
        if not data['idStation'].isdecimal():
           errors['idStation'] = 'type idStation incorrect'
           valid= False
        else:
            data["idStation"] = int(data["idStation"])
    else:
        valid = False

    if not valid:
        return (valid, errors, data)

    station = mStation.getStation(int(data['idStation']))
    if not station:
        errors['idStation'] = "Saisir une Station"
        valid = False
    else :
        data['idStation']=int(data['idStation'])


    return (valid, errors, data)
