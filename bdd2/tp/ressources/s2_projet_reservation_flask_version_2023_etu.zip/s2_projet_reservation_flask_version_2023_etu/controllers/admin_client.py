#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *
import datetime


from connexion_db import get_db

admin_client = Blueprint('admin_client', __name__,
                        template_folder='templates')

@admin_client.route('/admin/client/show')
def show_client():
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete2_1' FROM DUAL '''
    mycursor.execute(sql)
    clients = mycursor.fetchall()
    return render_template('admin/client/show_clients.html', clients=clients)

@admin_client.route('/admin/client/add', methods=['GET'])
def add_client():
    erreurs=[]
    donnees=[]
    return render_template('admin/client/add_client.html', erreurs=erreurs, donnees=donnees)

@admin_client.route('/admin/client/add', methods=['POST'])
def valid_add_client():
    nom = request.form.get('nom', '')
    adresse = request.form.get('adresse', '')
    datePaiement = request.form.get('datePaiement', '')

    dto_data={'nom': nom, 'adresse': adresse, 'datePaiement': datePaiement}
    valid, errors, dto_data = validator_client(dto_data)
    if valid:
        datePaiement=dto_data['datePaiement_us']
        tuple_insert = (nom,adresse,datePaiement)
        mycursor = get_db().cursor()
        sql = ''' SELECT 'requete2_2' FROM DUAL '''
        mycursor.execute(sql, tuple_insert)
        get_db().commit()
        message = u'client ajouté , libellé :'+nom
        flash(message)
        return redirect('/admin/client/show')
    return render_template('admin/client/add_client.html', erreurs=errors, donnees=dto_data)

@admin_client.route('/admin/client/delete', methods=['GET'])
def delete_client():
    mycursor = get_db().cursor()
    id_client = request.args.get('id', '')
    if not(id_client and id_client.isnumeric()):
        abort("404","erreur id client")
    tuple_delete=(id_client)
    nb_emprunts = 0
    sql = ''' SELECT 'requete2_6' FROM DUAL '''
    mycursor.execute(sql, tuple_delete)
    res_nb_emprunts = mycursor.fetchone()
    if 'nb_emprunts' in res_nb_emprunts.keys():
        nb_emprunts=res_nb_emprunts['nb_emprunts']
    if nb_emprunts == 0 :
        sql = ''' SELECT 'requete2_3' FROM DUAL '''
        mycursor.execute(sql, tuple_delete)
        get_db().commit()
        flash(u'client supprimé, id: ' + id_client)
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nb_emprunts) + u' emprunt(s) de cet client')
    return redirect('/admin/client/show')

@admin_client.route('/admin/client/edit', methods=['GET'])
def edit_client():
    id_client = request.args.get('id', '')
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete2_4' FROM DUAL '''
    mycursor.execute(sql, (id_client,))
    client = mycursor.fetchone()
    if client['date_paiement']:
        client['datePaiement']=client['date_paiement'].strftime("%d/%m/%Y")
    erreurs=[]
    return render_template('admin/client/edit_client.html', donnees=client, erreurs=erreurs)

@admin_client.route('/admin/client/edit', methods=['POST'])
def valid_edit_client():
    id = request.form.get('id', '')
    nom = request.form.get('nom', '')
    adresse = request.form.get('adresse', '')
    datePaiement = request.form.get('datePaiement', '')
    dto_data={'nom': nom, 'adresse': adresse, 'datePaiement': datePaiement, 'id':id}
    valid, errors, dto_data = validator_client(dto_data)
    if valid:
        datePaiement=dto_data['datePaiement_us']
        tuple_update = (nom,adresse,datePaiement,id)
        mycursor = get_db().cursor()
        sql = ''' SELECT 'requete2_5' FROM DUAL '''
        mycursor.execute(sql, tuple_update)
        get_db().commit()
        flash(u'client modifié, id: ' + id + " nom : " + nom)
        return redirect('/admin/client/show')
    return render_template('admin/client/edit_client.html', erreurs=errors, donnees=dto_data)

def validator_client(data):
    valid = True
    errors = dict()

    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False

    if not re.match(r'\w{2,}', data['nom']):
        errors['nom'] = "Le Nom doit avoir au moins deux caractères"
        valid = False

    try:
        datetime.datetime.strptime(data['datePaiement'], '%d/%m/%Y')
    except ValueError:
        errors['datePaiement'] = "Date n'est pas valide format:%d/%m/%Y"
        valid = False
    else:
        data['datePaiement_us'] = datetime.datetime.strptime(data['datePaiement'], "%d/%m/%Y").strftime("%Y-%m-%d")
    return (valid, errors, data)






