#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *

from connexion_db import get_db

admin_station = Blueprint('admin_station', __name__,
                        template_folder='templates')

@admin_station.route('/admin/station/show')
def show_station():
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete1_1' FROM DUAL '''
    mycursor.execute(sql)
    stations = mycursor.fetchall()
    return render_template('admin/station/show_stations.html', stations=stations)

@admin_station.route('/admin/station/add', methods=['GET'])
def add_station():
    erreurs=[]
    donnees=[]
    return render_template('admin/station/add_station.html', erreurs=erreurs, donnees=donnees)

@admin_station.route('/admin/station/add', methods=['POST'])
def valid_add_station():
    nom = request.form.get('nom', '')
    prenom = request.form.get('prenom', '')
    dto_data={'nom': nom, 'prenom':prenom}
    valid, errors = validator_station(dto_data)
    if valid:
        tuple_insert = (nom,prenom)
        mycursor = get_db().cursor()
        sql = ''' SELECT 'requete1_2' FROM DUAL '''
        mycursor.execute(sql, tuple_insert)
        get_db().commit()
        message = u'station ajouté , nom :'+nom
        flash(message),
        return redirect('/admin/station/show')
    return render_template('admin/station/add_station.html', erreurs=errors, donnees=dto_data)

@admin_station.route('/admin/station/delete', methods=['GET'])
def delete_station():
    mycursor = get_db().cursor()
    id_station = request.args.get('id', '')
    if not(id_station and id_station.isnumeric()):
        abort("404","erreur id station")
    tuple_delete=(id_station)
    nb_oeuvres = 0
    sql = ''' SELECT 'requete1_6' FROM DUAL '''
    # mycursor.execute(sql, tuple_delete)
    # res_nb_oeuvres = mycursor.fetchone()
    # if 'nb_oeuvres' in res_nb_oeuvres.keys():
    #     nb_oeuvres=res_nb_oeuvres['nb_oeuvres']
    if nb_oeuvres == 0 :
        sql = ''' SELECT 'requete1_3' FROM DUAL '''
        mycursor.execute(sql,tuple_delete)
        get_db().commit()
        flash(u'station supprimé, id: ' + id_station)
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nb_oeuvres) + u' oeuvre(s) de cet station')
    return redirect('/admin/station/show')

@admin_station.route('/admin/station/edit', methods=['GET'])
def edit_station():
    id = request.args.get('id', '')
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete1_4' FROM DUAL '''
    mycursor.execute(sql, (id,))
    station = mycursor.fetchone()
    print(id,sql)
    erreurs=[]
    return render_template('admin/station/edit_station.html', donnees=station, erreurs=erreurs)

@admin_station.route('/admin/station/edit', methods=['POST'])
def valid_edit_station():
    nom = request.form.get('nom', '')
    prenom = request.form.get('prenom', '')
    id = request.form.get('id', '')
    dto_data={'nom': nom, 'prenom':prenom, 'id': id}
    valid, errors = validator_station(dto_data)
    if valid:
        tuple_update = (nom, prenom, id)
        mycursor = get_db().cursor()
        sql = ''' SELECT 'requete1_5' FROM DUAL '''
        print(sql)
        mycursor.execute(sql, tuple_update)
        get_db().commit()
        flash(u'station modifié, id: ' + id + " nom : " + nom)
        return redirect('/admin/station/show')
    return render_template('admin/station/edit_station.html', donnees=dto_data, erreurs=errors)

def validator_station(data):
    valid = True
    errors = dict()
    if not re.match(r'\w{2,}', data['nom']):
        # flash('Nom doit avoir au moins deux caractères')
        errors['nom'] = 'Nom doit avoir au moins deux caractères'
        valid = False
    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False
    return (valid, errors)





