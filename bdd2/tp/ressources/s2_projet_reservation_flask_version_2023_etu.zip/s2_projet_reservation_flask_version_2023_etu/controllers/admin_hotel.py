#! /usr/bin/python
# -*- coding:utf-8 -*-
import re
from flask import *
import datetime

import os

from connexion_db import get_db

admin_hotel = Blueprint('admin_hotel', __name__,
                        template_folder='templates')

@admin_hotel.route('/admin/hotel/show')
def show_hotel():
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete3_1' FROM DUAL '''
    mycursor.execute(sql)
    hotels = mycursor.fetchall()
    return render_template('admin/hotel/show_hotel.html', hotels=hotels)

@admin_hotel.route('/admin/hotel/add', methods=['GET'])
def add_hotel():
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete3_6' FROM DUAL '''
    mycursor.execute(sql)
    auteurs = mycursor.fetchall()
    return render_template('admin/hotel/add_hotel.html', auteurs=auteurs, donnees=[], erreurs=[])

@admin_hotel.route('/admin/hotel/add', methods=['POST'])
def valid_add_hotel():
    mycursor = get_db().cursor()
    titre = request.form.get('titre', '')
    dateParution = request.form.get('dateParution', '')
    idAuteur = request.form.get('idAuteur', '')
    photo = request.form.get('photo', '')

    dto_data={'titre': titre, 'photo': photo, 'dateParution': dateParution, 'idAuteur': idAuteur}
    valid, errors, dto_data = validator_hotel(dto_data)
    if valid:
        dateParution = dto_data['dateParution_us']
        tuple_insert = (titre,dateParution,photo,idAuteur)
        sql = ''' SELECT 'requete3_2' FROM DUAL '''
        mycursor.execute(sql, tuple_insert)
        get_db().commit()
        print(u'hotel ajouté , nom: ', titre, ' - idAuteur:', idAuteur, ' - photo:', photo)
        message = u'hotel ajouté , nom:'+titre + '- idAuteur:' + idAuteur + ' - photo:' + photo
        flash(message)
        return redirect('/admin/hotel/show')
    sql = ''' SELECT 'requete3_6' FROM DUAL '''
    mycursor.execute(sql)
    auteurs = mycursor.fetchall()
    return render_template('admin/hotel/add_hotel.html', auteurs=auteurs, erreurs=errors, donnees=dto_data)

@admin_hotel.route('/admin/hotel/delete', methods=['GET'])
def delete_hotel():
    mycursor = get_db().cursor()
    id = request.args.get('id', '')
    if not(id and id.isnumeric()):
        abort("404","erreur id hotel")
    tuple_delete = (id,)

    nb_exemplaires = 0
    sql = ''' SELECT 'requete3_7' FROM DUAL '''
    mycursor.execute(sql, tuple_delete)
    res_nb_exemplaires = mycursor.fetchone()
    if 'nb_exemplaires' in res_nb_exemplaires.keys():
        nb_exemplaires=res_nb_exemplaires['nb_exemplaires']
    if nb_exemplaires == 0 :
        sql = ''' SELECT 'requete3_3' FROM DUAL '''
        mycursor.execute(sql, tuple_delete)
        get_db().commit()
        flash(u'hotel supprimée, id: ' + id)
    else :
        flash(u'suppression impossible, il faut supprimer  : ' + str(nb_exemplaires) + u' exemplaire(s) de cet hotel')
    return redirect('/admin/hotel/show')

@admin_hotel.route('/admin/hotel/edit', methods=['GET'])
def edit_hotel():
    id = request.args.get('id', '')
    mycursor = get_db().cursor()
    sql = ''' SELECT 'requete3_4' FROM DUAL '''
    mycursor.execute(sql, (id,))
    hotel = mycursor.fetchone()
    if hotel['dateParution']:
        hotel['dateParution']=hotel['dateParution'].strftime("%d/%m/%Y")
    sql = ''' SELECT 'requete3_6' FROM DUAL '''
    mycursor.execute(sql)
    auteurs = mycursor.fetchall()
    return render_template('admin/hotel/edit_hotel.html', donnees=hotel, auteurs=auteurs, erreurs=[])

@admin_hotel.route('/admin/hotel/edit', methods=['POST'])
def valid_edit_hotel():
    mycursor = get_db().cursor()
    id = request.form.get('id', '')
    titre = request.form.get('titre', '')
    dateParution = request.form.get('dateParution', '')
    idAuteur = request.form.get('idAuteur', '')
    photo = request.form.get('photo', '')
    dto_data={'titre': titre, 'photo': photo, 'dateParution': dateParution, 'idAuteur': idAuteur, 'id': id}
    print(dto_data)
    valid, errors, dto_data = validator_hotel(dto_data)
    if valid:
        dateParution=dto_data['dateParution_us']
        tuple_update = (titre,idAuteur,dateParution,photo,id)
        print(tuple_update)
        sql = ''' SELECT 'requete3_5' FROM DUAL '''
        mycursor.execute(sql, tuple_update)
        get_db().commit()
        print(u'hotel modifiée , titre : ', titre, ' - auteur_id:', idAuteur)
        message = u'hotel modifiée , titre:'+titre + '- auteur_id:' + idAuteur
        flash(message)
        return redirect('/admin/hotel/show')
    sql = ''' SELECT 'requete3_6' FROM DUAL '''
    mycursor.execute(sql)
    auteurs = mycursor.fetchall()
    return render_template('admin/hotel/edit_hotel.html', auteurs=auteurs, erreurs=errors, donnees=dto_data)


def validator_hotel(data):
    mycursor = get_db().cursor()
    # id,titre,date_parution,photo,auteur_id
    valid = True
    errors = dict()

    if 'id' in data.keys():
        if not data['id'].isdecimal():
           errors['id'] = 'type id incorrect'
           valid= False
    sql = ''' SELECT 'requete1_4' FROM DUAL '''
    mycursor.execute(sql, (data['idAuteur'],))
    auteur = mycursor.fetchone()
    if not auteur:
        flash("Auteur n'existe pas")
        errors['idAuteur'] = "Saisir un Auteur"
        valid = False
    else :
        data['idAuteur']=int(data['idAuteur'])

    if not re.match(r'\w{2,}', data['titre']):
        flash('Titre doit avoir au moins deux caractères')
        errors['titre'] = "Le titre doit avoir au moins deux caractères"
        valid = False

    try:
        datetime.datetime.strptime(data['dateParution'], '%d/%m/%Y')
    except ValueError:
        flash("la Date n'est pas valide")
        errors['dateParution'] = "la Date n'est pas valide format:%d/%m/%Y"
        valid = False
    else:
        data['dateParution_us'] = datetime.datetime.strptime(data['dateParution'], "%d/%m/%Y").strftime("%Y-%m-%d")

    if data['photo']:
        photo_path = os.path.join(current_app.root_path,
                                  'static', 'assets', 'images', data['photo'])

        if not os.path.isfile(photo_path):
            flash(f"Photo n'existe pas: { photo_path }")
            errors['photo'] = f"la Photo n'existe pas: { photo_path }"
            valid = False
    return (valid, errors, data)
