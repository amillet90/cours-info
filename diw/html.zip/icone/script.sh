ppmtowinicon -output favicon.ico favicon.ppm > Ppmtowinicon-sorties favicon.ico favicon.ppm

#https://stackoverflow.com/questions/4014823/does-a-favicon-have-to-be-32x32-or-16x16
#http://faviconit.com/fr/download/221bc869b60607746b004f388b5114a4d372835702849c13eee81458274180b01624864200


https://www.favicon-generator.org/        semble bien